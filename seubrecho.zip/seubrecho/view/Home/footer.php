<!-- Footer Inicio -->
<footer class="section-p1">
    <div class="col">
      <a href="index.php" style="margin: 0;"><img src="../img/icons/logoylogo.png" class="img-fluid"alt="Imagem responsiva"></a>
        <h4>Contato</h4>
        <p style="margin-left: 3%; margin-right: 15%;"><strong>Endereço: </strong>Av Jornalista Roberto Marinho 80, Cidade Monções, São Paulo</p>
        <p style="margin-left: 3%;"><strong>Telefone: </strong> 11 948607288</p>
        <p style="margin-left: 3%;"><strong>Horário </strong>10:00 - 18:00, Seg - Sex</p>
    <div class="follow">
      <h4>Redes sociais</h4>
        <i class="fa fa-facebook" aria-hidden="true"></i>
        <i class="fa fa-twitter" aria-hidden="true"></i>
        <i class="fa fa-instagram" aria-hidden="true"></i>
        <i class="fa fa-pinterest-p" aria-hidden="true"></i>
        <i class="fa fa-youtube" aria-hidden="true"></i>
    </div>
    </div>
    <div class="col "  style="margin-bottom: 6%;" >
        <h4>Sobre</h4>
        <a href="view/NossaCausa/uscause.php">Sobre nós</a>
        <a href="#"></a>
        <a href="#"></a>
        <a href="#"></a>
        <a href="#"></a>

    </div>
    <div class="col"  style="margin-bottom: 8%;">
        <h4>Minha conta</h4>
        <a href="view/newlc/view/logiin.php">Entrar</a>
        <a href="#"></a>
        <a href="#"></a>
        <a href="#"></a>
        
    </div>
    <div class="col pay" style="margin-bottom: 10%;">
        <h4>Formas de pagamento</h4>
        <p>Gateways de pagamento protegidos</p>
        <img src="../img/pay/pay.png" alt="">
    </div>
    <div class="copyright">
        <p><i class="fa fa-registered" aria-hidden="true"></i> Todos os Direitos Reservados</p>
    </div>
    
    
    </footer>

<!-- Footer Fim -->
