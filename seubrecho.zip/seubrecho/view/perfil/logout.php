<?php
session_start();
require_once '../../model/Manager.php';
$managers = new Managers();
$managers->Sair();

?>
  


